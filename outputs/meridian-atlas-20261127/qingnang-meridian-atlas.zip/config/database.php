<?php

use Illuminate\Support\Str;

$mysqlAddress = explode(':', (string) env('MYSQL_ADDRESS', '127.0.0.1:3306'), 2);
$defaultConnection = env('DB_CONNECTION', 'mysql');

return [

    'cases_table' => env('CASES_TABLE', 'qingnang.t_cases'),
    'cases_connection' => env('CASES_DB_CONNECTION', $defaultConnection),
    'prescriptions_table' => env('PRESCRIPTIONS_TABLE', 'qingnang.t_prescriptions'),
    'prescriptions_connection' => env('PRESCRIPTIONS_DB_CONNECTION', $defaultConnection),
    'meridians_table' => env('MERIDIANS_TABLE', 'qingnang.t_meridians'),
    'meridians_connection' => env('MERIDIANS_DB_CONNECTION', $defaultConnection),
    'acupoints_table' => env('ACUPOINTS_TABLE', 'qingnang.t_acupoints'),
    'acupoints_connection' => env('ACUPOINTS_DB_CONNECTION', $defaultConnection),
    'acupoint_image_base_url' => env('ACUPOINT_IMAGE_BASE_URL'),
    'books_table' => env('BOOKS_TABLE', 'qingnang.t_books'),
    'book_chapters_table' => env('BOOK_CHAPTERS_TABLE', 'qingnang.t_book_chapters'),
    'book_chapter_book_id_field' => env('BOOK_CHAPTER_BOOK_ID_FIELD', 'book_id'),
    'book_chapter_title_field' => env('BOOK_CHAPTER_TITLE_FIELD', 'title'),
    'book_chapter_content_field' => env('BOOK_CHAPTER_CONTENT_FIELD', 'content'),
    'book_chapter_volume_field' => env('BOOK_CHAPTER_VOLUME_FIELD', 'volume'),
    'book_chapter_shiyi_field' => env('BOOK_CHAPTER_SHIYI_FIELD', 'shiyi'),

    /*
    |--------------------------------------------------------------------------
    | Default Database Connection Name
    |--------------------------------------------------------------------------
    |
    | Here you may specify which of the database connections below you wish
    | to use as your default connection for all database work. Of course
    | you may use many connections at once using the Database library.
    |
    */

    'default' => env('DB_CONNECTION', 'mysql'),

    /*
    |--------------------------------------------------------------------------
    | Database Connections
    |--------------------------------------------------------------------------
    |
    | Here are each of the database connections setup for your application.
    | Of course, examples of configuring each database platform that is
    | supported by Laravel is shown below to make development simple.
    |
    |
    | All database work in Laravel is done through the PHP PDO facilities
    | so make sure you have the driver for your particular database of
    | choice installed on your machine before you begin development.
    |
    */

    'connections' => [

        'sqlite' => [
            'driver' => 'sqlite',
            'url' => env('DATABASE_URL'),
            'database' => env('DB_DATABASE', database_path('database.sqlite')),
            'prefix' => '',
            'foreign_key_constraints' => env('DB_FOREIGN_KEYS', true),
        ],

        'mysql' => [
            'driver' => 'mysql',
            'url' => env('DATABASE_URL'),
            'host' => env('MYSQL_HOST', $mysqlAddress[0]),
            'port' => env('MYSQL_PORT', $mysqlAddress[1] ?? '3306'),
            'database' => env('MYSQL_DATABASE', 'qingnang'),
            'username' => env('MYSQL_USERNAME'),
            'password' => env('MYSQL_PASSWORD'),
            'unix_socket' => env('DB_SOCKET', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'prefix_indexes' => true,
            'strict' => true,
            'engine' => null,
            'options' => extension_loaded('pdo_mysql') ? array_filter([
                PDO::MYSQL_ATTR_SSL_CA => env('MYSQL_ATTR_SSL_CA'),
            ]) : [],
        ],

        'pgsql' => [
            'driver' => 'pgsql',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '5432'),
            'database' => env('DB_DATABASE', 'forge'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8',
            'prefix' => '',
            'prefix_indexes' => true,
            'schema' => 'public',
            'sslmode' => 'prefer',
        ],

        'sqlsrv' => [
            'driver' => 'sqlsrv',
            'url' => env('DATABASE_URL'),
            'host' => env('DB_HOST', 'localhost'),
            'port' => env('DB_PORT', '1433'),
            'database' => env('DB_DATABASE', 'forge'),
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8',
            'prefix' => '',
            'prefix_indexes' => true,
        ],

    ],

    /*
    |--------------------------------------------------------------------------
    | Migration Repository Table
    |--------------------------------------------------------------------------
    |
    | This table keeps track of all the migrations that have already run for
    | your application. Using this information, we can determine which of
    | the migrations on disk haven't actually been run in the database.
    |
    */

    'migrations' => 'migrations',

    /*
    |--------------------------------------------------------------------------
    | Redis Databases
    |--------------------------------------------------------------------------
    |
    | Redis is an open source, fast, and advanced key-value store that also
    | provides a richer body of commands than a typical key-value system
    | such as APC or Memcached. Laravel makes it easy to dig right in.
    |
    */

    'redis' => [

        'client' => env('REDIS_CLIENT', 'phpredis'),

        'options' => [
            'cluster' => env('REDIS_CLUSTER', 'redis'),
            'prefix' => env('REDIS_PREFIX', Str::slug(env('APP_NAME', 'laravel'), '_').'_database_'),
        ],

        'default' => [
            'url' => env('REDIS_URL'),
            'host' => env('REDIS_HOST', '127.0.0.1'),
            'password' => env('REDIS_PASSWORD', null),
            'port' => env('REDIS_PORT', '6379'),
            'database' => env('REDIS_DB', '0'),
        ],

        'cache' => [
            'url' => env('REDIS_URL'),
            'host' => env('REDIS_HOST', '127.0.0.1'),
            'password' => env('REDIS_PASSWORD', null),
            'port' => env('REDIS_PORT', '6379'),
            'database' => env('REDIS_CACHE_DB', '1'),
        ],

    ],

];
