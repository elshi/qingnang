const { contentShare } = require('../../../utils/content-share');
const { getPrescriptionDetail } = require('../../../utils/prescriptions-api');
const sections = [
  { key: 'modern_dose', title: '现代剂量' },
  { key: 'indications', title: '主治' },
  { key: 'explanation', title: '方义方解' },
  { key: 'decoction', title: '煎服法' }
];

function formatDetail(item) {
  let explanation = item.explanation || '';
  const book = (item.source || '').trim();
  let sourceLocation = book && !book.startsWith('《') ? '《' + book + '》' : book;
  const citation = /(?:^|\r?\n)文献位置\r?\n(《[^\r\n]+)\s*$/.exec(explanation);
  if (citation) {
    explanation = explanation.slice(0, citation.index).trimEnd();
    sourceLocation = citation[1].trim().replace(/》\s*·\s*/, '》');
  }
  return {
    sourceLocation: sourceLocation || '出处未注明',
    sections: sections.map(section => ({
      ...section,
      content: section.key === 'explanation' ? explanation : item[section.key]
    })).filter(section => String(section.content || '').trim())
  };
}

Page({
  onShareAppMessage() { return contentShare('prescription', this.data.item); },
  data: { activeTab: 'detail', tabs: [{ key: 'detail', label: '详情' }, { key: 'notes', label: '笔记' }], item: null, sections: [], loading: true, error: '', disclaimer: getApp().getDisclaimer() },
  onLoad(options = {}) {
    this.prescriptionId = String(options.id === undefined ? '' : options.id);
    this.requestId = 0;
    this.loadDetail();
  },
  onUnload() { this.requestId += 1; this.unloaded = true; },
  async loadDetail() {
    if (this.unloaded) return;
    if (!/^\d{1,10}$/.test(this.prescriptionId) || Number(this.prescriptionId) > 4294967295) {
      this.setData({ loading: false, error: '经方 ID 无效' });
      return;
    }
    const requestId = ++this.requestId;
    this.setData({ loading: true, error: '' });
    try {
      const item = await getPrescriptionDetail(this.prescriptionId);
      if (requestId !== this.requestId || this.unloaded) return;
      this.setData({ item, ...formatDetail(item), loading: false });
    } catch (error) {
      if (requestId !== this.requestId || this.unloaded) return;
      this.setData({ loading: false, error: error.message || '经方详情加载失败，请稍后重试' });
    }
  },
  switchTab(event) { this.setData({ activeTab: event.currentTarget.dataset.key }); },
  retry() { this.loadDetail(); }
});
